<?php
/*
[ExtensionSettings]
DesignExtensions[]=css_dropdown

[StylesheetSettings]
CSSFileList[]=css_dropdown.css

[Css_dropdown]
goleft=6

*/
?>
