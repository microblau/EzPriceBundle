<?php /*

[TemplateSettings]
ExtensionAutoloadPath[]=css_dropdown

*/ ?>
